import { useState, useEffect } from "react";
import axios from "axios";
import React from "react";
import { API_BASE_URL } from "../config/apiConfig";
import "bootstrap/dist/css/bootstrap.min.css";

const ViewAllCustomers = () => {
  

  return (
    <div className="mt-3">
      <h1>View All customer</h1>
    </div>
  );
};

export default ViewAllCustomers;
