import { useState, useEffect } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { API_BASE_URL } from "../config/apiConfig";
import ".././css/MyWallet.css"; 

const MyWallet = () => {

  return (
    <div className="wallet-container d-flex align-items-center justify-content-center min-vh-100">
      <h2>My Walleets</h2>
    </div>
  );
};

export default MyWallet;
